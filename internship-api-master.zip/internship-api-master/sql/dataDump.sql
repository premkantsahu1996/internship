-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.4.8-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             10.2.0.5599
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for testing_genez
CREATE DATABASE IF NOT EXISTS `testing_genez` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `testing_genez`;

-- Dumping structure for table testing_genez.branch
CREATE TABLE IF NOT EXISTS `branch` (
  `branch_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `capacity` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`branch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Dumping data for table testing_genez.branch: ~3 rows (approximately)
DELETE FROM `branch`;
/*!40000 ALTER TABLE `branch` DISABLE KEYS */;
INSERT INTO `branch` (`branch_id`, `name`, `capacity`, `created_at`, `updated_at`) VALUES
	(1, 'Computer Dept', 60, '2020-08-07 13:26:23', NULL),
	(2, 'Electronics', 100, '2020-08-07 13:26:47', NULL),
	(3, 'IT', 80, '2020-08-07 13:27:22', NULL);
/*!40000 ALTER TABLE `branch` ENABLE KEYS */;

-- Dumping structure for table testing_genez.exam
CREATE TABLE IF NOT EXISTS `exam` (
  `exam_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `date` datetime NOT NULL,
  `duration` time NOT NULL,
  `question_count` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`exam_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Dumping data for table testing_genez.exam: ~4 rows (approximately)
DELETE FROM `exam`;
/*!40000 ALTER TABLE `exam` DISABLE KEYS */;
INSERT INTO `exam` (`exam_id`, `name`, `date`, `duration`, `question_count`, `created_at`, `updated_at`) VALUES
	(1, 'Maths Test', '2020-08-07 13:27:42', '01:00:00', 10, '2020-08-07 13:27:48', NULL),
	(2, 'English Test', '2020-08-07 13:28:05', '01:00:00', 11, '2020-08-07 13:28:18', NULL),
	(3, 'GK Test', '2020-08-07 13:28:28', '01:00:00', 15, '2020-08-07 13:28:38', NULL),
	(4, 'Aptitude Test', '2020-08-07 13:28:53', '00:30:00', 50, '2020-08-07 13:29:03', NULL);
/*!40000 ALTER TABLE `exam` ENABLE KEYS */;

-- Dumping structure for table testing_genez.question
CREATE TABLE IF NOT EXISTS `question` (
  `question_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `marks` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`question_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Dumping data for table testing_genez.question: ~0 rows (approximately)
DELETE FROM `question`;
/*!40000 ALTER TABLE `question` DISABLE KEYS */;
INSERT INTO `question` (`question_id`, `title`, `type`, `marks`, `created_at`, `updated_at`) VALUES
	(1, 'What is matter?', 'DESCRIPTIVE', 10, '2020-08-07 13:34:14', NULL),
	(2, 'What is an atom?', 'MCQ', 1, '2020-08-07 13:34:27', NULL),
	(3, 'Define evaporation', 'DESCRIPTIVE', 6, '2020-08-07 13:35:00', NULL);
/*!40000 ALTER TABLE `question` ENABLE KEYS */;

-- Dumping structure for table testing_genez.user
CREATE TABLE IF NOT EXISTS `user` (
  `user_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `firstname` varchar(200) NOT NULL,
  `lastname` varchar(200) NOT NULL,
  `role` varchar(200) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table testing_genez.user: ~2 rows (approximately)
DELETE FROM `user`;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`user_id`, `email`, `password`, `firstname`, `lastname`, `role`, `created_at`, `updated_at`) VALUES
	(1, 'mk@gmail.com', 'ffff', 'Mohit', 'Kumar', 'STUDENT', '2020-08-07 13:29:32', NULL),
	(2, 'km@gmail.com', 'ffff', 'Mohit', 'Kumar', 'ADMIN', '2020-08-07 13:29:56', NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;

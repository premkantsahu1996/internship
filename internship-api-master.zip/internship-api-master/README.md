# tg-backend
TG Backend task

1. Rename .env.development to .env and replace values. 
2. npm i
3. nodemon index.js
4. Database dump is available in sql folder
5. Swagger Docs @ http://localhost:4000/api-docs/

Project Details: 
1. Made in Node Js
2. Uses Express Js for routing
3. JWT for Authentication
4. Swagger for documentation
5. MariaDB for SQL 
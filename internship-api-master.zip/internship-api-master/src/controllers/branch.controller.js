const branchService = require('../service/branch.service');

const getAllBranchData = async (req, res) => {
  const userRole = req.res.locals.user.role;

  if (userRole !== 'STUDENT') {
    return res
      .status(403)
      .json({ msg: 'User unauthorized to view this data.' });
  }

  const getAllBranchData = await branchService.getAllBranchData();
  return res.status(200).json(getAllBranchData);
};

module.exports = {
  getAllBranchData
};

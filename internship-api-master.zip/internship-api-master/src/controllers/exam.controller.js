const examService = require('../service/exam.service');

const getAllExamData = async (req, res) => {
    const userRole = req.res.locals.user.role;

    if (userRole !== 'ADMIN') {
      return res
        .status(403)
        .json({ msg: 'User unauthorized to view this data.' });
    }

  const getAllExamData = await examService.getAllExamData();
  return res.status(200).json(getAllExamData);
};

module.exports = {
  getAllExamData
};

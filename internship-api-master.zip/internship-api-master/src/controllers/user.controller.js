const jwt = require('jsonwebtoken');
const userService = require('../service/user.service');
const CONSTANTS = require('../shared/constants');
const authService = require('../shared/auth.service');

const authenticateUser = async (req, res) => {
  let user;
  try {
    user = await userService.getUser(req.body);
  } catch (err) {
    return res
      .status(500)
      .json({ msg: 'some error occoured', error: err.message });
  }

  user = JSON.parse(JSON.stringify(user));

  if (user === null) {
    return res.status(401).json({ msg: 'Invalid credentials' });
  }

  const payload = {
    user
  };

  const jwtToken = authService.generateAuthToken(payload);

  res.setHeader(
    CONSTANTS.JWT_HEADER_STRING,
    `${CONSTANTS.JWT_TOKEN_PREFIX} ${jwtToken}`
  );

  return res.status(200).json({ token: jwtToken });
};

module.exports = {
  authenticateUser
};

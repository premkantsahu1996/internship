const questionService = require('../service/question.service');

const { validationResult } = require('express-validator');

const getAllQuestionData = async (req, res) => {
  const userRole = req.res.locals.user.role;

  if (userRole !== 'ADMIN') {
    return res
      .status(403)
      .json({ msg: 'User unauthorized to view this data.' });
  }
  const getAllQuestionData = await questionService.getAllQuestionData();
  return res.status(200).json(getAllQuestionData);
};

const addNewQuestion = async (req, res) => {

  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ "msg": "validation error",errors: errors.array() });
  }

  const userRole = req.res.locals.user.role;

  if (userRole !== 'ADMIN') {
    return res
      .status(403)
      .json({ msg: 'User unauthorized to for this operation.' });
  }
  let data;
  try {
    data = await questionService.addNewQuestion(req.body);
  } catch (err) {
    return res
      .status(400)
      .json({ msg: 'some error occoured.', error: err.message });
  }

  return res.status(200).json(data);
};

module.exports = {
  getAllQuestionData,
  addNewQuestion
};

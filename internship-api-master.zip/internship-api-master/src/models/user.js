module.exports = (sequelize, DataTypes) => {
  const User = sequelize.define(
    'User',
    {
      userId: {
        type: DataTypes.BIGINT,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true,
        field: 'user_id'
      },
      email: {
        type: DataTypes.STRING(200),
        allowNull: false,
        field: 'email'
      },
      password: {
        type: DataTypes.STRING(200),
        allowNull: false,
        field: 'password'
      },
      firstName: {
        type: DataTypes.STRING(200),
        allowNull: false,
        field: 'firstname'
      },
      lastName: {
        type: DataTypes.STRING(200),
        allowNull: false,
        field: 'lastname'
      },
      role: {
        type: DataTypes.STRING(200),
        allowNull: false,
        field: 'role'
      },
      createdAt: {
        type: DataTypes.DATE,
        allowNull: false,
        field: 'created_at'
      },
      updatedAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'updated_at'
      }
    },
    {
      tableName: 'user'
    }
  );
  return User;
};

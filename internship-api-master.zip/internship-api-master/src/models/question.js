module.exports = (sequelize, DataTypes) => {
  const Question = sequelize.define(
    'Question',
    {
      questionId: {
        type: DataTypes.BIGINT,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true,
        field: 'question_id'
      },
      title: {
        type: DataTypes.STRING(200),
        allowNull: false,
        field: 'title'
      },
      type: {
        type: DataTypes.STRING(200),
        allowNull: false,
        field: 'type',
        in: ['DESCRPITVE', 'MCQ']
      },
      marks: {
        type: DataTypes.INTEGER,
        allowNull: false,
        field: 'marks',
        max: 10,
        min: 1
      },
      createdAt: {
        type: DataTypes.DATE,
        allowNull: false,
        field: 'created_at'
      },
      updatedAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'updated_at'
      }
    },
    {
      tableName: 'question'
    }
  );
  return Question;
};

module.exports = (sequelize, DataTypes) => {
  const Exam = sequelize.define(
    'Exam',
    {
      examId: {
        type: DataTypes.BIGINT,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true,
        field: 'exam_id'
      },
      name: {
        type: DataTypes.STRING(100),
        allowNull: false,
        field: 'name'
      },
      date: {
        type: DataTypes.DATE(),
        allowNull: false,
        field: 'date'
      },
      duration: {
        type: DataTypes.TIME(),
        allowNull: false,
        field: 'duration'
      },
      questionCount: {
        type: DataTypes.INTEGER,
        allowNull: false,
        field: 'question_count'
      },
      createdAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'created_at'
      },
      updatedAt: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'updated_at'
      }
    },
    {
      tableName: 'exam'
    }
  );
  return Exam;
};

const Sequelize = require('sequelize');
const db = require('../models/index');

const { Exam } = db.sequelize.models;

const getAllExamData = async (req, res) => {
  const data = await Exam.findAll({
    attributes: ['examId','name','date','duration','questionCount']
  });

  return data;
};

module.exports = {
  getAllExamData
};

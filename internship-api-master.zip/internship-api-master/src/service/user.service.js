const Sequelize = require('sequelize');
const db = require('../models/index');

const { User } = db.sequelize.models;

const getUser = async (req, res) => {
  const data = await User.findOne({
    attributes: [
      'userId',
      'email',
      'firstName',
      'lastName',
      'role'
    ],
    where: { email: req.email, password: req.password }
  });

  return data;
};

module.exports = {
  getUser
};

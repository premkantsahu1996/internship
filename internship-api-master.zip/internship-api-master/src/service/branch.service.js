const Sequelize = require('sequelize');
const db = require('../models/index');

const { Branch } = db.sequelize.models;

const getAllBranchData = async (req, res) => {
  const data = await Branch.findAll({
    attributes: ['branchId', 'name', 'capacity']
  });

  return data;
};

module.exports = {
  getAllBranchData
};

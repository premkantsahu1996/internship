const Sequelize = require('sequelize');
const db = require('../models/index');

const { Question } = db.sequelize.models;

const getAllQuestionData = async (req, res) => {
  const data = await Question.findAll({
    attributes: ['questionId', 'title', 'type', 'marks']
  });

  return data;
};

const addNewQuestion = async (req, res) => {
  const data = await Question.create(req);
  return data;
};

module.exports = {
  getAllQuestionData,
  addNewQuestion
};

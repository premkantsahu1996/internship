const express = require('express');
const userRoutes = require('./user.routes');
const examRoutes = require('./exam.routes');
const branchRoutes = require('./branch.routes');
const questionRoutes = require('./question.routes');

const apiRouter = express.Router();

apiRouter.get('/healthcheck', (req, res) => {
  const greeting = 'healthcheck.ok';
  res.json(greeting);
});

apiRouter.use('/user', userRoutes);
apiRouter.use('/exam', examRoutes);
apiRouter.use('/branch', branchRoutes);
apiRouter.use('/question', questionRoutes);

module.exports = apiRouter;

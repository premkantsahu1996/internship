const express = require('express');

const questionRoutes = express.Router();
const { body } = require('express-validator');
const questionController = require('../controllers/question.controller');

const authService = require('../shared/auth.service');

questionRoutes.get(
  '/questions',
  authService.validateAuthToken,
  questionController.getAllQuestionData
);

questionRoutes.post(
  '/question',
  authService.validateAuthToken,
  [
    body('title').isString(),
    body('type').isString().isIn(['MCQ', 'DESCRIPTIVE']),
    body('marks').isInt({ min: 1, max: 10 })
  ],
  questionController.addNewQuestion
);

module.exports = questionRoutes;

const express = require('express');

const examRoutes = express.Router();

const examController = require('../controllers/exam.controller');

const authService = require('../shared/auth.service');

examRoutes.get(
  '/exams',
  authService.validateAuthToken,
  examController.getAllExamData
);

module.exports = examRoutes;

const express = require('express');

const branchRoutes = express.Router();

const branchController = require('../controllers/branch.controller');

const authService = require('../shared/auth.service');

branchRoutes.get(
  '/branches',
  authService.validateAuthToken,
  branchController.getAllBranchData
);

module.exports = branchRoutes;

const jwt = require('jsonwebtoken');

const CONSTANTS = require('../shared/constants');

const validateAuthToken = (req, res, next) => {
  const authorizationHeader = req.headers.authorization;

  let result;

  if (authorizationHeader) {
    const token = req.headers.authorization.split(' ')[1];
    const options = {
      expiresIn: CONSTANTS.JWT_TOKEN_EXPIRY,
      issuer: process.env.JWT_ISSUER
    };

    try {
      result = jwt.verify(token, process.env.JWT_SECRET_KEY, options);
      //   res.locals.userDetails = result;
      res.locals.user = result.user;
      next();
    } catch (err) {
      res
        .status(403)
        .send({ msg: 'Token Invalid or expired', error: err.message });
    }
  } else {
    res.status(403).send({ msg: 'No auth token' });
  }
};

const generateAuthToken = payload => {
  const options = {
    expiresIn: CONSTANTS.JWT_TOKEN_EXPIRY,
    issuer: process.env.JWT_ISSUER
  };
  const secret = process.env.JWT_SECRET_KEY;
  const token = jwt.sign(payload, secret, options);
  return token;
};

module.exports = {
  validateAuthToken,
  generateAuthToken
};
